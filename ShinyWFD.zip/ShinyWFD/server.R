library(shiny)
library(datasets)
library(plotly)
library(ggplot2)
library(reshape2)
library(lubridate)

print(paste("server accessed at ",Sys.time()))

# Define server logic required to summarize and view the selected dataset
shinyServer(function(input, output) 
{
output$Sites<-renderText({
  validate(need(input$Dates[2]>input$Dates[1],"END DATE is greater than START DATE: Choose an end date correctly"))
  validate(need(difftime(input$Dates[2],input$Dates[1],"days")<= 30,"Date Range is greater than 30 Days"))
  if (length(input$Site)==0){
  } else { 
paste("By default, the following table depicts the WFD Numbers for ",input$Site," from ", format(parse_date_time(input$Dates[1],c("%y-%m-%d")),"%m/%d/%y")," to ",format(parse_date_time(input$Dates[2],c("%y-%m-%d")),"%m/%d/%y"),".",sep="",collapse="")
}
    })
	
output$a<-renderTable({
  validate(need(input$Dates[2]>input$Dates[1],"END DATE is greater than START DATE: Choose an end date correctly"))
  validate(need(difftime(input$Dates[2],input$Dates[1],"days")<= 30,"Date Range is greater than 30 Days"))
  if (length(input$Site)==0){
  } else {
    fileName<-paste("C:\\Daily Health Check and Monitoring\\Test\\WFD-Code\\WFD_DATA_",input$Site,".csv",sep="",collapse="")
    read.csv(fileName)
    }
})

output$plot<-renderPlot({
  validate(need(input$Dates[2]>input$Dates[1],"END DATE is greater than START DATE: Choose an end date correctly"))
  validate(need(difftime(input$Dates[2],input$Dates[1],"days")<= 30,"Date Range is greater than 30 Days"))
    
    if (length(input$Site)==0){
    } else {
      fileName<-paste("C:\\Daily Health Check and Monitoring\\Test\\WFD-Code\\WFD_DATA_",input$Site,".csv",sep="",collapse="")
      rcsv<-read.csv(fileName)
      
      # if(rcsv$Date>=input$Dates && rcsv$Date<=input$Dates){
      #   rcsv1[+1,]=c(as.character(currdate),weekdays(currdate),TotWFDCnt,TotSockCnt,TotWFDAIMSCnt)
      # }
      
      wfds<-melt(rcsv[,c('Date','Total_WFD','WFD_Due_To_Socket_Timeout','WFD_Due_To_AIMS')],id.vars=1)
      ggplot(wfds,aes(x=Date,y=as.numeric(value)))+geom_bar(aes(fill=variable),position="identity",stat="identity")+ scale_fill_discrete(name="Legends",breaks=c("Total_WFD","WFD_Due_To_Socket_Timeout","WFD_Due_To_AIMS"),labels=c("Total WFD","Number Of WFD Due To Socket Timeout","Number Of WFD Due To AIMS"))+theme(axis.text.x=element_blank())+ geom_text(aes(label=as.numeric(value)),angle=45,position=position_dodge(width = 0.8))+scale_y_continuous("WFD Count")
   
    }

  },height=800, width=1000
)

})