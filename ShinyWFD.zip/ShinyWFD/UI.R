library(shiny)
print(paste("UI accessed at ",Sys.time()))
# Define UI for dataset viewer application
shinyUI(
fluidPage
(
	fluidRow
	(
		column(3,
		radioButtons("Site","Site Name",selected=character(0),
			c("Detroit,MI"="Detroit",
				"Durham,NC"="Durham",
				"Montgomery,NY"="Montgomery",
				"Ontario,CA"="Ontario"))
		),
		column(3,
		dateRangeInput("Dates",label=h3("Input The Date"),
				  start=Sys.Date()-32,end=Sys.Date()-2,
				  min="2016-06-01",max=Sys.Date()-2,format="mm/dd/yyyy"),
		
				  tags$em(tags$i(tags$h6("** 2:00 AM Data is available")))
		),
	
	# column(9,
	# 	br(),
	# 	br(),
	# 	actionButton("act",label="Get the WFD Data"),
	# 	#submitButton("Get the WFD Data"),
	# 	p("Click the button to get the WFD Data")
	# 	),

        #tags$style("#sites{color:red;}"),
  #      tableOutput('a'),
# 	column(12,
#         plotOutput("plot",width="100%")
# 	),
	mainPanel(br(),htmlOutput('Sites'),
	          tabsetPanel(
	  tabPanel("Tabular",tableOutput('a')),
	  tabPanel("Graphical",plotOutput("plot",width="100%"))
	))
)	
)
)
